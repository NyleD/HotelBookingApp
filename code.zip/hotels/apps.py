from django.apps import AppConfig


class HotelsConfig(AppConfig):
    name = 'hotels'
