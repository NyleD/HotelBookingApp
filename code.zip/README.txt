$ python manage.py help populate_db
Usage: manage.py populate_db [options] <foo bar ...>

our help string comes here

Options:
...
1) get in django-enviroment  using above 

2)
RUN create_hotel_rooms.py on hotelrooms.csv
change path 
